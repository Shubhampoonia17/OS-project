document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('sim-form');
  const resultsSection = document.getElementById('results-section');
  const loadingOverlay = document.getElementById('loading-overlay');
  const chartContainer = document.getElementById('chart-container');
  const stepControls = document.getElementById('step-controls');
  let chart = null;

  // Step-by-step state
  let steps = [];
  let currentStep = 0;
  let playInterval = null;
  let playSpeed = 700; // ms per step
  let tableMeta = { frames: 0, refstr: [] };

  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    // Show loading
    loadingOverlay.classList.add('active');
    resultsSection.classList.add('hidden');
    chartContainer.classList.add('hidden');
    stepControls.classList.add('hidden');
    // Gather input
    const frames = document.getElementById('frames').value;
    const refstr = document.getElementById('refstr').value;
    const algorithm = document.getElementById('algorithm').value;
    // AJAX
    const response = await fetch('/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frames, refstr, algorithm })
    });
    const data = await response.json();
    // Parse steps from backend (simulate again in JS for animation)
    tableMeta.frames = parseInt(frames);
    tableMeta.refstr = refstr.split(',').map(x => x.trim()).filter(x => x !== '').map(Number);
    steps = simulateSteps(tableMeta.frames, tableMeta.refstr, algorithm);
    currentStep = 0;
    // Hide loading
    setTimeout(() => {
      loadingOverlay.classList.remove('active');
      renderStep(currentStep);
      resultsSection.classList.remove('hidden');
      resultsSection.classList.add('animate-fade-in');
      // Chart.js
      if (data.stats) {
        chartContainer.classList.remove('hidden');
        if (chart) chart.destroy();
        chart = new Chart(document.getElementById('results-chart').getContext('2d'), {
          type: 'bar',
          data: {
            labels: ['Hits', 'Faults'],
            datasets: [{
              label: 'Simulation Stats',
              data: [data.stats.hits, data.stats.faults],
              backgroundColor: [
                'rgba(34,211,238,0.8)',
                'rgba(244,63,94,0.8)'
              ],
              borderRadius: 12,
              borderWidth: 0
            }]
          },
          options: {
            plugins: { legend: { display: false } },
            scales: {
              x: { grid: { color: '#232336' }, ticks: { color: '#e5e7ef' } },
              y: { grid: { color: '#232336' }, ticks: { color: '#e5e7ef' }, beginAtZero: true }
            },
            animation: { duration: 900, easing: 'easeOutQuart' },
            responsive: true,
            maintainAspectRatio: false
          }
        });
      }
      stepControls.classList.remove('hidden');
    }, 700);
  });

  // Step controls
  document.getElementById('play-btn').onclick = () => {
    if (playInterval) return;
    playInterval = setInterval(() => {
      if (currentStep < steps.length - 1) {
        currentStep++;
        renderStep(currentStep);
      } else {
        clearInterval(playInterval);
        playInterval = null;
      }
    }, playSpeed);
  };
  document.getElementById('pause-btn').onclick = () => {
    if (playInterval) {
      clearInterval(playInterval);
      playInterval = null;
    }
  };
  document.getElementById('step-btn').onclick = () => {
    if (currentStep < steps.length - 1) {
      currentStep++;
      renderStep(currentStep);
    }
  };

  // --- Step-by-step simulation logic (JS version of backend) ---
  function simulateSteps(frames, refstr, algorithm) {
    let memory = [];
    let steps = [];
    let recent = [];
    let pointer = 0;
    let use_bit = Array(frames).fill(0);
    let memArr = Array(frames).fill(null);
    for (let i = 0; i < refstr.length; i++) {
      let page = refstr[i];
      let hit = false;
      if (algorithm === 'FIFO') {
        hit = memory.includes(page);
        if (!hit) {
          if (memory.length < frames) memory.push(page);
          else { memory.shift(); memory.push(page); }
        }
      } else if (algorithm === 'LRU') {
        hit = memory.includes(page);
        if (hit) {
          recent.splice(recent.indexOf(page), 1);
          recent.push(page);
        } else {
          if (memory.length < frames) memory.push(page);
          else {
            let lru = recent.shift();
            memory[memory.indexOf(lru)] = page;
          }
          recent.push(page);
        }
      } else if (algorithm === 'Optimal') {
        hit = memory.includes(page);
        if (!hit) {
          if (memory.length < frames) memory.push(page);
          else {
            let future = refstr.slice(i+1);
            let indices = memory.map(m => future.indexOf(m) === -1 ? Infinity : future.indexOf(m));
            let idx = indices.indexOf(Math.max(...indices));
            memory[idx] = page;
          }
        }
      } else if (algorithm === 'Clock') {
        if (memArr.includes(page)) {
          hit = true;
          use_bit[memArr.indexOf(page)] = 1;
        } else {
          while (use_bit[pointer] === 1) {
            use_bit[pointer] = 0;
            pointer = (pointer + 1) % frames;
          }
          memArr[pointer] = page;
          use_bit[pointer] = 1;
          pointer = (pointer + 1) % frames;
        }
        steps.push([memArr.slice(), hit]);
        continue;
      }
      let memSnapshot = (algorithm === 'Clock') ? memArr.slice() : memory.slice();
      steps.push([memSnapshot, hit]);
    }
    return steps;
  }

  // Render a single step
  function renderStep(stepIdx) {
    const frames = tableMeta.frames;
    const refstr = tableMeta.refstr;
    let html = '<div class="overflow-x-auto"><table class="min-w-full text-center border-separate border-spacing-y-2 text-base"><thead><tr>';
    html += '<th class="px-2 py-1 text-gray-400">Step</th>';
    for (let i = 0; i < refstr.length; i++) {
      html += `<th class="px-2 py-1 text-blue-400 font-bold">${refstr[i]}</th>`;
    }
    html += '</tr></thead><tbody>';
    for (let f = 0; f < frames; f++) {
      html += `<tr><td class="font-bold text-purple-400">Frame ${f+1}</td>`;
      for (let s = 0; s <= stepIdx; s++) {
        let mem = steps[s][0];
        let val = mem[f] !== undefined && mem[f] !== null ? mem[f] : '';
        let highlight = (s === stepIdx) ? 'ring-2 ring-blue-400' : '';
        html += `<td class="bg-[#181825] border border-[#232336] rounded-lg shadow transition-all duration-300 hover:bg-[#232336] cursor-pointer ${highlight}" title="Frame ${f+1}">${val}</td>`;
      }
      for (let s = stepIdx+1; s < refstr.length; s++) {
        html += `<td></td>`;
      }
      html += '</tr>';
    }
    html += `<tr><td class="font-bold text-fuchsia-400">Hit/Fault</td>`;
    for (let s = 0; s <= stepIdx; s++) {
      let hit = steps[s][1];
      let highlight = (s === stepIdx) ? (hit ? 'ring-2 ring-cyan-400' : 'ring-2 ring-pink-400') : '';
      html += `<td class="${hit ? 'text-cyan-400 font-bold' : 'text-pink-400 font-bold'} animate-pulse ${highlight}" title="${hit ? 'Page Hit' : 'Page Fault'}">${hit ? '✔' : '✖'}</td>`;
    }
    for (let s = stepIdx+1; s < refstr.length; s++) {
      html += `<td></td>`;
    }
    html += '</tr>';
    html += '</tbody></table></div>';
    resultsSection.innerHTML = html;
  }
}); 