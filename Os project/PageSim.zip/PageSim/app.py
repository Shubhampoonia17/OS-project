from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/explore')
def explore():
    return render_template('explore.html')

@app.route('/simulate', methods=['GET'])
def simulate_page():
    algorithm = request.args.get('algorithm', '')
    return render_template('simulate.html', selected_algorithm=algorithm)

def simulate_fifo(frames, refstr):
    memory = []
    steps = []
    hits = 0
    for idx, page in enumerate(refstr):
        hit = page in memory
        if not hit:
            if len(memory) < frames:
                memory.append(page)
            else:
                memory.pop(0)
                memory.append(page)
        else:
            hits += 1
        steps.append((list(memory), hit))
    return steps, hits

def simulate_lru(frames, refstr):
    memory = []
    recent = []
    steps = []
    hits = 0
    for page in refstr:
        hit = page in memory
        if hit:
            hits += 1
            recent.remove(page)
            recent.append(page)
        else:
            if len(memory) < frames:
                memory.append(page)
            else:
                lru = recent.pop(0)
                memory[memory.index(lru)] = page
            recent.append(page)
        steps.append((list(memory), hit))
    return steps, hits

def simulate_optimal(frames, refstr):
    memory = []
    steps = []
    hits = 0
    for i, page in enumerate(refstr):
        hit = page in memory
        if hit:
            hits += 1
        else:
            if len(memory) < frames:
                memory.append(page)
            else:
                future = refstr[i+1:]
                indices = [(future.index(m) if m in future else float('inf')) for m in memory]
                idx = indices.index(max(indices))
                memory[idx] = page
        steps.append((list(memory), hit))
    return steps, hits

def simulate_clock(frames, refstr):
    memory = [None] * frames
    use_bit = [0] * frames
    pointer = 0
    steps = []
    hits = 0
    for page in refstr:
        if page in memory:
            hits += 1
            use_bit[memory.index(page)] = 1
            steps.append((list(memory), True))
            continue
        while use_bit[pointer] == 1:
            use_bit[pointer] = 0
            pointer = (pointer + 1) % frames
        memory[pointer] = page
        use_bit[pointer] = 1
        pointer = (pointer + 1) % frames
        steps.append((list(memory), False))
    return steps, hits

@app.route('/simulate', methods=['POST'])
def simulate():
    data = request.get_json()
    frames = int(data.get('frames', 3))
    refstr = [int(x.strip()) for x in data.get('refstr', '').split(',') if x.strip().isdigit()]
    algorithm = data.get('algorithm', 'FIFO')
    if algorithm == 'FIFO':
        steps, hits = simulate_fifo(frames, refstr)
    elif algorithm == 'LRU':
        steps, hits = simulate_lru(frames, refstr)
    elif algorithm == 'Optimal':
        steps, hits = simulate_optimal(frames, refstr)
    elif algorithm == 'Clock':
        steps, hits = simulate_clock(frames, refstr)
    else:
        return jsonify({'status': 'error', 'html': '<div class="text-red-500">Unknown algorithm.</div>'})
    faults = len(refstr) - hits
    fault_rate = (faults / len(refstr)) * 100 if refstr else 0
    # Generate HTML table with modern dark mode and tooltips
    table = '<div class="overflow-x-auto"><table class="min-w-full text-center border-separate border-spacing-y-2 text-base"><thead><tr>'
    table += '<th class="px-2 py-1 text-gray-400">Step</th>'
    for i, page in enumerate(refstr):
        table += f'<th class="px-2 py-1 text-blue-400 font-bold">{page}</th>'
    table += '</tr></thead><tbody>'
    for f in range(frames):
        table += f'<tr><td class="font-bold text-purple-400">Frame {f+1}</td>'
        for mem, _ in steps:
            val = mem[f] if f < len(mem) and mem[f] is not None else ''
            table += f'<td class="bg-[#181825] border border-[#232336] rounded-lg shadow transition-all duration-300 hover:bg-[#232336] cursor-pointer" title="Frame {f+1}">{val}</td>'
        table += '</tr>'
    table += '<tr><td class="font-bold text-fuchsia-400">Hit/Fault</td>'
    for _, hit in steps:
        table += f'<td class="{('text-cyan-400 font-bold' if hit else 'text-pink-400 font-bold')} animate-pulse" title="{('Page Hit' if hit else 'Page Fault')}">{'✔' if hit else '✖'}</td>'
    table += '</tr>'
    table += '</tbody></table></div>'
    stats = f'''<div class="flex flex-wrap gap-4 justify-center mt-6">
        <div class="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-6 py-4 rounded-xl shadow-lg text-lg font-semibold animate-fade-in">Page Hits: {hits}</div>
        <div class="bg-gradient-to-r from-pink-500 to-fuchsia-500 text-white px-6 py-4 rounded-xl shadow-lg text-lg font-semibold animate-fade-in">Page Faults: {faults}</div>
        <div class="bg-gradient-to-r from-green-400 to-teal-400 text-white px-6 py-4 rounded-xl shadow-lg text-lg font-semibold animate-fade-in">Fault Rate: {fault_rate:.2f}%</div>
    </div>'''
    html = table + stats
    return jsonify({'status': 'success', 'html': html, 'stats': {'hits': hits, 'faults': faults, 'fault_rate': fault_rate}})

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True) 